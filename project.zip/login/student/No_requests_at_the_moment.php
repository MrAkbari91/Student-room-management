
   <?php
      include 'include/header.php';
    ?>
    <div>
      <div class="row m-0 pt-5 pb-5">
        <div class="col-md-6 m-auto pt-5 pb-5 border-bg">
          <div>
            <div class="text-center pb-0 border-bottom mb-3">
              <h2 class="text-color font-weight-bold">View Request</h2>
            </div>
            <div>
              <h2 class="text-color font-weight-bold text-center py-3" >There Is No Requests Submitted.</h2>
              <div class="d-flex justify-content-center">
                <a href="../student.php"><button class="btn btn-colo box-sh mx-1 w-1 p-7-30">Back</button></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php
      include 'include/footer.php';
  ?>