<?php
include("dbcon.php");
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../css/style.css">
    <title></title>
</head>

<body>
    <main>
        <div class="bg-color pb-3 pt-3">
            <div class="d-flex justify-content-around text-center align-items-center boder-w p-3">
                <div>
                    <img src="../../image/download.jpeg" class="w-75" alt="logo">
                </div>
                <div>
                    <h2 class="text-white"> Jubail University College <br> Dormitory system</h2>
                </div>
                <div>
                    <img src="../../image/rightimg.png" class="w-75" alt="rightimg">
                </div>
            </div>
        </div>