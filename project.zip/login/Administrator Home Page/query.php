<?php

session_start();
$array = $_SESSION['data'];

if(isset($_POST['submit'])){
    
}
?>