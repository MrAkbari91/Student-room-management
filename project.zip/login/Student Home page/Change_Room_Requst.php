<?php
      include 'include/header.php';
    ?>
    <div>
      <div class="row m-0 pt-5 pb-5">
        <div class="col-md-10 m-auto py-5 border-bg">
          <div>
            <div class="text-center pb-0 border-bottom mb-3">
              <h2 class="text-color font-weight-bold">Change Room Report</h2>
            </div>
            <div>
              <div class="row d-flex mt-4 ">
                  <div class="col-md-4 m-auto pt-5 pb-5 border-bg">
                    <div class="d-flex justify-content-center">
                      <div class="">
                        <div>
                          <p class="p-1">Name:</p>
                        </div>
                        <div>
                          <p class="p-1">Student Id:</p>
                        </div>
                        <div>
                          <p class="p-1">Email:</p>
                        </div>
                      </div>  
                       <div>
                        <div class="bg-text">
                          <p class="p-1">Bader Mohsen</p>
                        </div>
                        <div class="bg-text">
                          <p class="p-1">381900860</p>
                        </div>
                        <div class="bg-text">
                          <p class="p-1">xyz@gmail.com</p>
                        </div>
                      </div> 
                    </div>            
                  </div>
                  <div class=" col-md-6 d-flex  m-auto pt-5 pb-5 justify-content-around">
                    <div>
                      <p>From:</p>
                        <div class="bg-text px-3">
                          <p class="p-1">Buildingn:5</p>
                        </div>
                        <div class="bg-text px-3">
                          <p class="p-1">Room:5</p>
                        </div>
                    </div>
                    <div>
                      <p>To:</p>   
                        <div class="bg-text px-3">
                          <p class="p-1">Buildingn:5</p>
                        </div>
                        <div class="bg-text px-3">
                          <p class="p-1">Room:5</p>
                        </div>                   
                    </div>
                  </div>
              </div>
              <div class="text-center pt-5">
                <h2 class="text-color font-weight-bold">A Change Request Has Been Sent To The Administrator.</h2>
              </div>
              <div class="d-flex justify-content-center ">
                <a href="../student.php"><button class="btn btn-colo box-sh w-1 mt-5">Back</button></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php
      include 'include/footer.php';
    ?>